ROT & RUIN — co-op app
========================

This folder is the co-op client on its own: the game's renderer, the room
client, a web app manifest and the icons. It has no single-player game in it.

How to use it
-------------
1. Put these files on a web address. Any static host works — the same GitHub
   Pages site, a free static host, or a "web server" app on the phone.
2. Open that address in Chrome and choose "Install app" (or Menu > Install app).
3. Tap SERVER at the top of the page and paste the room server's address,
   for example:  https://rot-and-ruin-coop.onrender.com
   It is remembered after that.

Straight from the phone's Downloads folder
------------------------------------------
Opening index.html directly from storage is not recommended: browsers treat
such a page as an untrusted, origin-less document and will usually refuse its
network requests, so it cannot reach the room server. If you want to try it, the
page will ask for the server address first, but expect it to fail on Android
Chrome. Serving the folder, or installing the hosted copy, is the reliable route.

The room
--------
Everyone who opens the app with the same room code shares one world. The room
holds four survivors. Runs live in the server's memory: if the server sleeps or
restarts, the run ends and everyone reopens the app for a fresh world.

Controls
--------
WASD move, mouse aim, click to fire, R reload, F medkit, Shift sprint.
