ROT & RUIN - TRAILER KIT
========================

Eight plain files. Read them in this order.

1. trailer-20s.md
   The 20-second cut that goes at the top of the Steam page. Four text lines
   with exact in and out times, shot by shot.

2. trailer-shotlist.md
   The same cut as a recording list: every shot with its in/out time and frame
   numbers, what has to happen on screen, how to set it up in the game, and what
   to watch for. This is the one to have open while you play.

3. trailer-script.md
   The full 60-second trailer, plus the 6-second loop. Everything the 20-second
   cut was trimmed from.

4. trailer-voiceover.md
   Voice-over lines for the 60-second cut, timed to each beat, split into three
   recording blocks of 12 seconds or less.

5. steam-trailer-paste.txt
   Plain-ASCII values for the Steamworks trailer form: name, category, language,
   order, encoder settings, thumbnail. Paste straight in.

6. youtube-trailer-pack.txt
   The same trailer on YouTube: title and alternates, a 759-character
   description, fifteen tags, which frame to use as the thumbnail, and the
   upload settings. Paste each block straight into the upload screen.

7. trailer-blurb.txt
   The short description that sits by the trailer on the store page, with shorter
   variants.

8. iphone-install.txt
   Putting the game and the co-op page on an iPhone home screen, in Safari, and
   the Airplane Mode check that proves the offline copy works.

Notes
-----
- No video is included: these are the documents you shoot from.
- The storyboard screenshots the shot list refers to are in the game's project
  folder, not in this zip, to keep the download small.
- All text is plain ASCII where it is meant to be pasted into Steam or YouTube.
- The 20-second cut is the same MP4 for both places. Encode once, upload to
  Steam and YouTube; a second encode brings back banding in the dark shots.
