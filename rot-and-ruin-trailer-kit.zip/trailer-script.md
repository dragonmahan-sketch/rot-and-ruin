# ROT & RUIN - trailer script

Three cuts from one shoot: a 60-second Steam trailer, a 20-second version for
the top of the store page and social, and a 6-second loop. Same footage, same
order, just trimmed. No voice-over anywhere - the text lines and the gunfire do
the talking, so it works with sound off, which is how most people first meet a
Steam page.

Everything below is capturable from the game as it stands. No new art needed.

**1.0.1 note:** the game has weather now, and the 60-second cut uses all three
states - rain for the opening street and the first wave, fog for the brute, a
storm for the night and the ending. The 20-second cut is in `trailer-20s.md`
and uses rain and storm only. No shot was added for the weather; it was put
into shots that already existed, so both cuts keep their length.

---

## The 60-second cut

**0:00 - 0:07 - Nothing yet**
Black. Wind, a loose sheet of metal somewhere, one distant moan.
Text, small, centred, one line at a time:

> The world ended quietly.
> The dead did not.

Cut on the second line - no fade.

**0:07 - 0:15 - The street, in rain**
Slow push-in over the ruined outskirts in daylight, rain falling in slanted
streaks, ground dark and wet. Buildings, a burnt car, a crate against a wall.
Nothing moves but the rain.
Text, lower left, as if a field note:

> One stretch of city.
> No way out but through.

**0:15 - 0:22 - The first wave**
Gameplay, no cuts: pistol, three shamblers walking in from the right through the
same rain. Two shots, one reload. The HUD is visible and stays visible for the
rest of the trailer - people need to believe this is a game you play, not a
cinematic.

> Six weapons. Ammo you have to find.

**0:22 - 0:29 - Speed**
Fast cut to runners at full tilt, three of them, closing, rain still coming
sideways. Then a shotgun blast that ends it. The cut lands on the bang.

> Three kinds of dead.

**0:29 - 0:37 - Weight**
Fog, thick enough that the far side of the street is gone. A brute walks out of
it through the middle of the frame, eats four hits, keeps coming. Hold the shot
too long on purpose - that discomfort is the point. Player retreats, fires while
backing up, kills it at the last second.

> Brutes soak up the ammo and keep coming.

Fog is the right weather here and only here: the brute is close, so losing the
distance costs nothing, and something arriving out of a haze is the whole idea of
the beat.

**0:37 - 0:45 - The boss**
Cut to wave 5, clear sky - the fog goes with the cut, which is what makes the
boss read as a change of scene. The boss, the locked cache behind it, the fight
in progress. Player wins, walks to the cache, opens it: a weapon they did not
have. Cut before the pickup animation finishes.

> Every fifth wave, something bigger.

**0:45 - 0:54 - Night, in a storm**
The street again, same angle as 0:07, now dark and raining hard. Flashlight
cone, runners inside it, one outside it that you hear before you see. Player
kills the light for a beat, then turns it back on and there are two more. At
0:51.5 lightning lights the whole street for about half a second, and the street
is fuller than any of the previous shots showed.

> Night is a different game.

**0:54 - 1:00 - The end**
Smoke grenade into a crowd, frag behind it, the blast, then the death stamp.
Hard cut to black on the stamp.

> How long do you last?

Title, clean, on black:

> **ROT & RUIN**

Below it, small:

> Out now on Steam · fully offline · one file, no launcher

---

## Beat sheet, 60-second cut

| # | In - out | Beat | Picture | Sound |
| --- | --- | --- | --- | --- |
| 1 | 0:00 - 0:07 | Nothing yet | Black, two lines of text | Wind, metal, one moan |
| 2 | 0:07 - 0:15 | The street | Rain over the empty outskirts, push-in | Rain bed starts, drone enters at 0:15 |
| 3 | 0:15 - 0:22 | First wave | Shamblers, pistol, reload, rain | Two shots, reload |
| 4 | 0:22 - 0:29 | Speed | Runners closing, rain sideways | Running, then shotgun on the cut |
| 5 | 0:29 - 0:37 | Weight | Fog, brute out of it, four hits, kill | Heavy steps, shots, rain muffled |
| 6 | 0:37 - 0:45 | Boss | Clear sky, wave 5, boss, cache opens | Drone lifts, boss noise, cache |
| 7 | 0:45 - 0:51 | Night | Storm, cone, extra runner after the light | Rain hard, breathing, drone down |
| 8 | 0:51.5 - 0:52.5 | Lightning | Whole street lit, more of them | One thunder crack |
| 9 | 0:52.5 - 0:54 | Back to dark | Cone only, they are close | Rain, breathing |
| 10 | 0:54 - 1:00 | The end | Smoke, frag, death stamp, title | Frag is the loudest sound, then silence |

---

## The 20-second cut

Take 0:00-0:07 text, then 0:22 shotgun bang, 0:29 brute, 0:45 night, 0:54 title.
Five shots, four lines of text. This is the one that autoplays on the store page,
so it has to land without sound: keep every text line on screen for at least two
seconds. Full timings, frames and weather staging are in `trailer-20s.md` and
`trailer-shotlist.md`.

---

## The 6-second loop

Night, in the storm, flashlight on, runners arriving in the cone, one shot, back
to the first frame. No text. For the top of a post or a store widget. Set the
storm before rolling - the loop is short enough that a weather change landing
inside it looks like a glitch.

---

## Staging the weather

The weather runs on its own clock. In the browser build, open the console (F12)
and type one line per take:

```
__wx.kind = 'rain';  __wx.level = 1; __wx.hold = 600;   // beats 2, 3, 4
__wx.kind = 'fog';   __wx.level = 1; __wx.hold = 600;   // beat 5
__wx.kind = 'storm'; __wx.level = 1; __wx.hold = 600;   // beats 7, 8, 9
__wx.kind = 'clear'; __wx.hold = 600;                   // beat 6
```

Lightning on demand: type `__wx.nextFlash = 0.6;` just before rolling and a
strike lands about a second later.

Weather is visual only - it changes no difficulty, damage or sight - so nothing
in the shoot needs a retake because the sky made the fight harder.

---

## Sound

- **0:00-0:15** - no music at all. Wind, metal, one moan, then rain arriving at
  0:07. Silence is the cheapest tension you own.
- **0:15** - a single low drone enters and stays under everything until the end,
  rising maybe a semitone across the whole minute. Nothing melodic.
- **Gunfire is the rhythm.** Do not put a beat under the shooting; let the
  reloads and the shotgun do it.
- **0:29 (fog, brute)** - pull the rain back and put the brute's footsteps on
  top. Fog should sound like it, not just look like it.
- **0:45 (night)** - pull the drone down and add the runner's breathing.
- **0:51.5 (lightning)** - one thunder crack. It needs its own air; do not let
  it sit under a gunshot.
- **0:54** - the frag grenade is the loudest thing in the trailer. Everything
  after it is silence under the title.

## Capture notes

- 1920×1080, 60 fps, highest graphics level, then cut at 30 fps for delivery.
  Rain is thinnest at the low graphics settings, so this matters more than it
  did before the weather.
- Record with the HUD on. It is the proof the game is real.
- Capture each beat as a clean 20-30 second take and cut from that; do not try to
  act the trailer live in one pass.
- Set the weather at the start of each take and give it eight seconds to fade in
  fully before the action starts.
- The death stamp and pause stamp are good hard-cut frames - they read as
  punctuation rather than as UI.
- Keep the mouse cursor out of frame: play with a hidden cursor or crop 2 px.

## Frame stand-ins already in the project

Storyboard each beat against these screenshots before shooting:

| Beat | File |
| --- | --- |
| 0:07 street, day | `files/steam-03-day-wave7.png` |
| 0:07 street in rain | `shots/check-rain.png` (weather pass, day rain) |
| 0:15 first wave | `files/steam-01-night-swarm.png` (composition only) |
| 0:22 runners | `files/game-play.png` |
| 0:29 brute | `files/steam-04-day-brute.png` (fog not yet captured - shoot it) |
| 0:37 boss and cache | `files/steam-05-weapon-cache.png` |
| 0:45 night | `files/steam-02-night-pickup.png` |
| 0:45 night in storm | `shots/check-storm.png` and `shots/check-flash2.png` |
| 0:54 death stamp | `files/death-stamp.png` |
| title card | `files/steam-allages-01.png` |
