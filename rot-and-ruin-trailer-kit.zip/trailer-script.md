# ROT & RUIN — trailer script

Three cuts from one shoot: a 60-second Steam trailer, a 20-second version for
the top of the store page and social, and a 6-second loop. Same footage, same
order, just trimmed. No voice-over anywhere — the text lines and the gunfire do
the talking, so it works with sound off, which is how most people first meet a
Steam page.

Everything below is capturable from the game as it stands. No new art needed.

---

## The 60-second cut

**0:00 – 0:07 — Nothing yet**
Black. Wind, a loose sheet of metal somewhere, one distant moan.
Text, small, centred, one line at a time:

> The world ended quietly.
> The dead did not.

Cut on the second line — no fade.

**0:07 – 0:15 — The street**
Slow push-in over the ruined outskirts in daylight. Buildings, a burnt car, a
crate against a wall. Nothing moves.
Text, lower left, as if a field note:

> One stretch of city.
> No way out but through.

**0:15 – 0:22 — The first wave**
Gameplay, no cuts: pistol, three shamblers walking in from the right. Two shots,
one reload. The HUD is visible and stays visible for the rest of the trailer —
people need to believe this is a game you play, not a cinematic.

> Six weapons. Ammo you have to find.

**0:22 – 0:29 — Speed**
Fast cut to runners at full tilt, three of them, closing. Then a shotgun blast
that ends it. The cut lands on the bang.

> Three kinds of dead.

**0:29 – 0:37 — Weight**
A brute walks through the middle of the frame, eats four hits, keeps coming.
Hold the shot too long on purpose — that discomfort is the point. Player
retreats, fires while backing up, kills it at the last second.

> Brutes soak up the ammo and keep coming.

**0:37 – 0:45 — The boss**
Cut to wave 5. The boss, the locked cache behind it, the fight in progress.
Player wins, walks to the cache, opens it: a weapon they did not have.
Cut before the pickup animation finishes.

> Every fifth wave, something bigger.

**0:45 – 0:54 — Night**
The street again, same angle as 0:07, now dark. Flashlight cone, runners inside
it, one outside it that you hear before you see. Player kills the light for a
beat, then turns it back on and there are two more.

> Night is a different game.

**0:54 – 1:00 — The end**
Smoke grenade into a crowd, frag behind it, the blast, then the death stamp.
Hard cut to black on the stamp.

> How long do you last?

Title, clean, on black:

> **ROT & RUIN**

Below it, small:

> Out now on Steam · fully offline · one file, no launcher

---

## The 20-second cut

Take 0:00–0:07 text, then 0:22 shotgun bang, 0:29 brute, 0:45 night, 0:54 title.
Five shots, four lines of text. This is the one that autoplays on the store page,
so it has to land without sound: keep every text line on screen for at least two
seconds.

---

## The 6-second loop

Night, flashlight on, runners arriving in the cone, one shot, back to the first
frame. No text. For the top of a post or a store widget.

---

## Sound

- **0:00–0:15** — no music at all. Wind, metal, one moan. Silence is the cheapest
  tension you own.
- **0:15** — a single low drone enters and stays under everything until the end,
  rising maybe a semitone across the whole minute. Nothing melodic.
- **Gunfire is the rhythm.** Do not put a beat under the shooting; let the
  reloads and the shotgun do it.
- **0:45 (night)** — pull the drone back down and add the runner's breathing.
- **0:54** — the frag grenade is the loudest thing in the trailer. Everything
  after it is silence under the title.

## Capture notes

- 1920×1080, 60 fps, highest graphics level, then cut at 30 fps for delivery.
- Record with the HUD on. It is the proof the game is real.
- Capture each beat as a clean 20–30 second take and cut from that; do not try to
  act the trailer live in one pass.
- The death stamp and pause stamp are good hard-cut frames — they read as
  punctuation rather than as UI.
- Keep the mouse cursor out of frame: play with a hidden cursor or crop 2 px.

## Frame stand-ins already in the project

Storyboard each beat against these screenshots before shooting:

| Beat | File |
| --- | --- |
| 0:07 street, day | `files/steam-03-day-wave7.png` |
| 0:15 first wave | `files/steam-01-night-swarm.png` (composition only) |
| 0:22 runners | `files/game-play.png` |
| 0:29 brute | `files/steam-04-day-brute.png` |
| 0:37 boss and cache | `files/steam-05-weapon-cache.png` |
| 0:45 night | `files/steam-02-night-pickup.png` |
| 0:54 death stamp | `files/death-stamp.png` |
| title card | `files/steam-allages-01.png` |
