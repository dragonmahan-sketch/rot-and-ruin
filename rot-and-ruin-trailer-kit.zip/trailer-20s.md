# ROT & RUIN — 20-second trailer (store page cut)

For the top of the Steam page: the first video on the page, so it has to work
muted and without a click. Four text lines only, everything else is footage and
sound. Nothing on screen is longer than 5 seconds and no text line is on screen
for less than 2 seconds.

Total running time: **20.0 seconds.** No voice-over.

---

## Shots and timings

**Shot 1 · 0:00.0 – 0:05.0**
Daylight street, slow push-in. Nothing moving — buildings, a burnt car, a crate
against a wall.
**Text, in 0:00.8 · out 0:04.6**
> One street. No way out.

**Shot 2 · 0:05.0 – 0:09.0**
Shamblers walking in from the right. Two pistol shots at 0:06.4, one reload. The
shot ends on a shotgun blast at 0:09.0 — cut on the bang, not after it.
**Text, in 0:05.4 · out 0:08.6**
> Three kinds of dead.

**Shot 3 · 0:09.0 – 0:13.0**
The same street, now dark. Flashlight cone with two runners inside it, one more
moving outside the light. The player kills the light for half a second.
**Text, in 0:09.4 · out 0:12.8**
> Night is a different game.

**Shot 4 · 0:13.0 – 0:15.5**
Smoke into a crowd, frag behind it, blast at 0:14.2. Loudest sound in the cut.
**No text** — let the blast have the frame.

**Shot 5 · 0:15.5 – 0:17.5**
The death stamp, held, then hard cut.
**Text, in 0:15.7 · out 0:17.3**
> How long do you last?

**Title · 0:17.5 – 0:20.0**
Black. **ROT & RUIN**, then small underneath:
> Out now on Steam · fully offline · no launcher

---

## Text cards

| # | Line | In | Out | On screen |
| --- | --- | --- | --- | --- |
| 1 | One street. No way out. | 0:00.8 | 0:04.6 | 3.8 s |
| 2 | Three kinds of dead. | 0:05.4 | 0:08.6 | 3.2 s |
| 3 | Night is a different game. | 0:09.4 | 0:12.8 | 3.4 s |
| 4 | How long do you last? | 0:15.7 | 0:17.3 | 1.6 s |

Line 4 is the shortest on purpose — it lands over the death stamp and gets out
before the title. If it feels rushed, start it at 0:15.4 instead and let the
stamp hold it.

---

## Sound

- **0:00 – 0:05** wind, loose metal, one distant moan. No music.
- **0:05** a single low drone enters and stays under the rest of the cut, rising
  barely at all.
- Gunfire is the rhythm: shots at 0:06.4, the shotgun at 0:09.0, the frag at
  0:14.2. Nothing melodic under any of them.
- **0:15.5** everything stops for the death stamp. Silence under the title.

---

## Steam specifics

- **1920×1080, H.264 MP4, 30 fps.** Upload it as a trailer and move it to first
  position on the store page — Steam autoplays the first video muted, so every
  line above has to carry on its own.
- **Keep text out of the bottom 15%** of the frame: the player's controls fade in
  there and will sit on top of your text.
- **Keep text inside the middle 80%** as well, so it survives the smaller
  in-page player.
- **Start the first text at 0:00.8, not 0:00.0** — autoplay can begin mid-fade,
  and a line that is already there when the video starts reads as an accident.
- **End on the title, not on black.** The last visible frame is what some
  placements show before play begins.
- No captions file is needed: there is no spoken audio, and the text lines are
  already the script.

## What was cut from the 60-second version

The brute and the wave-five boss are gone — they were the middle of the long cut
and there is no room for both here. The night beat survives because it is the one
that changes the rules, and the frag blast replaces the boss as the escalation
before the ending.
