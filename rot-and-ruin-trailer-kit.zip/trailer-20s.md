# ROT & RUIN - 20-second trailer (store page cut)

For the top of the Steam page: the first video on the page, so it has to work
muted and without a click. Four text lines only, everything else is footage and
sound. Nothing on screen is longer than 5 seconds and no text line is on screen
for less than 2 seconds.

Total running time: **20.0 seconds.** No voice-over.

**What changed for 1.0.1:** the game has weather now, so the cut is shot in it.
Shot 1 opens in rain and Shot 3 turns the night into a storm with one lightning
strike as punctuation. Two shots, no new text cards, no change to the timing -
the four lines and every in/out point below are the same as before.

---

## Shots and timings

**Shot 1 · 0:00.0 - 0:05.0**
Daylight street in rain, slow push-in. Nothing moving - buildings, a burnt car,
a crate against a wall, rain streaking past all of it and the ground dark and
wet.
**Text, in 0:00.8 · out 0:04.6**
> One street. No way out.

**Shot 2 · 0:05.0 - 0:09.0**
Shamblers walking in from the right, still in the rain. Two pistol shots at
0:06.4, one reload. The shot ends on a shotgun blast at 0:09.0 - cut on the bang,
not after it.

**Text, in 0:05.4 · out 0:08.6**
> Three kinds of dead.

**Shot 3 · 0:09.0 - 0:13.0**
The same street, now dark, in a storm: heavier slanted rain, the flashlight cone
with two runners inside it, one more moving outside the light. The player kills
the light for half a second. At 0:12.4 a lightning strike lights the whole
street for about 0.4 s and there are two more runners than the cone showed.
**Text, in 0:09.4 · out 0:12.8**
> Night is a different game.

**Shot 4 · 0:13.0 - 0:15.5**
Smoke into a crowd, frag behind it, blast at 0:14.2. Loudest sound in the cut.
The wet ground throws the blast light back at the camera - keep that in the
frame, it is the shot the weather earns.
**No text** - let the blast have the frame.

**Shot 5 · 0:15.5 - 0:17.5**
The death stamp, held, then hard cut.
**Text, in 0:15.7 · out 0:17.3**
> How long do you last?

**Title · 0:17.5 - 0:20.0**
Black. **ROT & RUIN**, then small underneath:
> Out now on Steam · fully offline · no launcher

**If this cut is used for the 1.0.1 event post** rather than only the store page,
swap the small line for:

> Weather update - free, out now

Everything else stays as it is. Do not put a version number on the store page
title card; it dates the video the moment the next build ships.

---

## Beat sheet

Every beat, what is on screen, what carries the sound. "Card" means a text card
is on screen for that beat.

| # | In - out | Frames (30 fps) | Picture | Sound | Card |
| --- | --- | --- | --- | --- | --- |
| 1 | 0:00.0 - 0:00.8 | 000-024 | Rain over the empty street, push-in starting | Wind, metal, one distant moan | - |
| 2 | 0:00.8 - 0:04.6 | 024-138 | Same shot, push-in to 106% | Same, nothing added | 1 |
| 3 | 0:04.6 - 0:05.0 | 138-150 | Push-in completes | First low drone enters at 0:05 | - |
| 4 | 0:05.0 - 0:06.4 | 150-192 | Shamblers in from the right, rain on them | Rain bed under everything | - |
| 5 | 0:06.4 - 0:07.6 | 192-228 | Two pistol shots, first shambler down | Two shots, close | 2 (from 0:05.4) |
| 6 | 0:07.6 - 0:09.0 | 228-270 | Reload on screen, crowd still standing | Reload clatter, then shotgun | 2 until 0:08.6 |
| 7 | 0:09.0 - 0:10.2 | 270-306 | Hard cut to night storm, cone already on | Rain heavier, wind up | - |
| 8 | 0:10.2 - 0:11.0 | 306-330 | Runner enters the cone | Runner's breathing | 3 (from 0:09.4) |
| 9 | 0:11.0 - 0:11.6 | 330-348 | Flashlight off, screen drops to almost nothing | Rain only, no music | 3 |
| 10 | 0:11.6 - 0:12.4 | 348-372 | Light back on, one more runner | Breathing closer | 3 |
| 11 | 0:12.4 - 0:12.8 | 372-384 | **Lightning** - whole street lit, two extra runners | Thunder cracks inside the rain | 3 until 0:12.8 |
| 12 | 0:12.8 - 0:13.0 | 384-390 | Street falls back to the cone | Rain, drone | - |
| 13 | 0:13.0 - 0:13.6 | 390-408 | Crowd thick in the open, wet ground | Crowd noise | - |
| 14 | 0:13.6 - 0:14.2 | 408-426 | Smoke into the middle of them | Smoke pop | - |
| 15 | 0:14.2 - 0:15.5 | 426-465 | Frag detonates behind the smoke | **Loudest sound in the cut** | - |
| 16 | 0:15.5 - 0:15.7 | 465-471 | Cut to the death stamp | Everything stops | - |
| 17 | 0:15.7 - 0:17.3 | 471-519 | Death stamp held, no cursor | Silence | 4 |
| 18 | 0:17.5 - 0:20.0 | 525-600 | Black, then title, then the small line | Silence | title |

---

## Text cards

| # | Line | In | Out | On screen |
| --- | --- | --- | --- | --- |
| 1 | One street. No way out. | 0:00.8 | 0:04.6 | 3.8 s |
| 2 | Three kinds of dead. | 0:05.4 | 0:08.6 | 3.2 s |
| 3 | Night is a different game. | 0:09.4 | 0:12.8 | 3.4 s |
| 4 | How long do you last? | 0:15.7 | 0:17.3 | 1.6 s |

Line 4 is the shortest on purpose - it lands over the death stamp and gets out
before the title. If it feels rushed, start it at 0:15.4 instead and let the
stamp hold it.

Card 3 is the one the weather sits under. The lightning at 0:12.4 is the last
quarter-second of that card: keep the card up through the strike, let the flash
carry it out, and cut at 0:13.0.

---

## Staging the weather

The weather runs on its own clock, so waiting for rain wastes takes. Open the
browser console on the game (F12, Console tab) and type:

```
__wx.kind = 'rain'; __wx.level = 1; __wx.hold = 600;
```

That gives you steady rain for ten minutes. For the night storm in Shot 3:

```
__wx.kind = 'storm'; __wx.level = 1; __wx.hold = 600;
```

To bring a lightning strike within a second of pressing record:

```
__wx.nextFlash = 0.6;
```

Set it before the take, not during - the strike comes about a second later and
you want it landing at 0:12.4, not at 0:10.

Back to no weather with `__wx.kind = 'clear';`.

Two rules for the shoot:

- **Rain and storm only in this cut.** Fog is in the game and it looks good, but
  it deliberately softens the far side of the screen, which in a four-second
  shot reads as an empty street rather than a foggy one. Use fog for store
  screenshots and stills, not for the trailer.
- **Weather is visual only.** It changes nothing about difficulty, damage or
  sight, so nothing here needs a second take because the sky made the fight
  harder. The only retake reason is rain hiding a body you needed to see.

---

## Sound

- **0:00 - 0:05** wind, loose metal, one distant moan, rain on metal and glass.
  No music. The rain is the bed, not an event: it starts at full and stays.
- **0:05** a single low drone enters and stays under the rest of the cut, rising
  barely at all.
- Gunfire is the rhythm: shots at 0:06.4, the shotgun at 0:09.0, the frag at
  0:14.2. Nothing melodic under any of them.
- **0:12.4** one thunder crack, tight and dry, as the lightning lands. It must
  not overlap the shotgun or the frag - it is the only other loud moment and it
  needs its own air.
- **0:15.5** everything stops for the death stamp. Silence under the title.

---

## Steam specifics

- **1920×1080, H.264 MP4, 30 fps.** Upload it as a trailer and move it to first
  position on the store page - Steam autoplays the first video muted, so every
  line above has to carry on its own.
- **Keep text out of the bottom 15%** of the frame: the player's controls fade in
  there and will sit on top of your text.
- **Keep text inside the middle 80%** as well, so it survives the smaller
  in-page player.
- **Start the first text at 0:00.8, not 0:00.0** - autoplay can begin mid-fade,
  and a line that is already there when the video starts reads as an accident.
- **End on the title, not on black.** The last visible frame is what some
  placements show before play begins.
- No captions file is needed: there is no spoken audio, and the text lines are
  already the script.

## What was cut from the 60-second version

The brute and the wave-five boss are gone - they were the middle of the long cut
and there is no room for both here. The night beat survives because it is the one
that changes the rules, and the frag blast replaces the boss as the escalation
before the ending. The weather did not add a shot: it was put into shots that
already existed, which is why the cut is still 20.0 seconds.
