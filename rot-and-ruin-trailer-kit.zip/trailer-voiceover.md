# ROT & RUIN — trailer voice-over

Written to the 60-second cut in `trailer-script.md`, same timecodes.

**Total: 71 words. About 29 seconds of speech across 60 seconds** — roughly half
the trailer is deliberately silent, which is what makes the gunfire land. The
longest single passage is 11 seconds, so nothing here needs more than a short
breath to read.

Read at a slow, level pace — about 2.4 words a second, which is slower than you
think. Every line ends before the sound it belongs to, never over it.

---

## The lines, beat by beat

**0:00 – 0:07 · Black**
> This is what's left of the city.

6 words · 3 sec · leaves four seconds of wind and one moan alone before the cut.

**0:07 – 0:15 · The street, daylight**
> One street. No doors that lock. Nothing coming to help.

10 words · 4 sec. Slow push-in; nothing is moving, so let the line sit in the
quiet and do not hurry it.

**0:15 – 0:22 · First wave**
> You start with a pistol and twelve rounds. Make them count.

11 words · 5 sec. Say it *before* the shooting starts. The two shots and the
reload are the answer to the line, not a background to it.

**0:22 – 0:29 · Runners**
> They don't all walk.

4 words · 2 sec. Flat, matter-of-fact. The shotgun blast cuts you off — that is
intentional, so do not try to finish over it.

**0:29 – 0:37 · The brute**
> Some of them take everything you've got and keep coming.

11 words · 5 sec. Start it while the brute is still walking. It should sound
like you are describing something you have already seen too many times.

**0:37 – 0:45 · Boss and cache**
> Every fifth wave, one of them is guarding something worth having.

12 words · 5 sec. The only line with a little lift in it. The cache opening is
the reward beat of the trailer.

**0:45 – 0:54 · Night**
> Then the light goes, and the rules change with it.

11 words · 5 sec. Quietest line of the set. Pull back from the mic slightly so
the flashlight click and the breathing are louder than you.

**0:54 – 1:00 · Death stamp, then title**
> One run. However long it lasts.

6 words · 3 sec. Land "lasts" on the death stamp, then stop. The title card is
silent — do not read the game's name, let the logo say it.

---

## If you record in blocks

Three takes, none of them long enough to need a re-read:

| Block | Covers | Words | Speech |
| --- | --- | --- | --- |
| A | 0:00 – 0:22 (black, street, first wave) | 27 | about 12 sec |
| B | 0:22 – 0:45 (runners, brute, boss) | 27 | about 12 sec |
| C | 0:45 – 1:00 (night, ending) | 17 | about 8 sec |

Record each block three times and pick per line. Keep the same distance from the
mic across all three or the cuts will show.

---

## Delivery

- Low, close, no smile, no upward inflection at the ends of sentences.
- Do not sell. Describe. The footage is doing the selling.
- Never stress a word for effect — if a line needs help, the line is wrong.
- Leave a full beat of silence after each line rather than filling it.
- Record at 48 kHz mono, dry, no reverb; add a touch of room later if the mix
  feels too clean against the wind.

## Alternate lines

If any of the above reads wrong in the mix, swap in one of these without
touching the timing — they are all the same length or shorter:

- 0:00 — *"Nobody was left to bury them."*
- 0:07 — *"No map. No safe room. Just the street."*
- 0:15 — *"A pistol, twelve rounds, and a street full of them."*
- 0:29 — *"Some of them don't care how much ammo you have."*
- 0:45 — *"When the light goes, they stop pretending to be slow."*
- 0:54 — *"See how long you last."*

## One thing to avoid

Do not say "survive" anywhere in the voice-over. The on-screen text already asks
*"How long do you last?"*, and the moment a narrator says "survive" the trailer
sounds like every other one.
