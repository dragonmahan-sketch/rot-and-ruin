# ROT & RUIN - 20-second trailer, recording shot list

Six shots, 600 frames at 30 fps. Record at 1920×1080, capture at 60 fps, cut on
a 30 fps timeline. HUD stays on in every gameplay shot.

Frame numbers below are 30 fps timeline frames, so they line up with the edit.

**1.0.1 weather:** Shot 1 is shot in rain and Shot 3 in a night storm. Nothing
else about the shoot changed - same six shots, same timings, same frames.

| Shot | In | Out | Length | Frames |
| --- | --- | --- | --- | --- |
| 1 | 0:00.0 | 0:05.0 | 5.0 s | 000–150 |
| 2 | 0:05.0 | 0:09.0 | 4.0 s | 150–270 |
| 3 | 0:09.0 | 0:13.0 | 4.0 s | 270–390 |
| 4 | 0:13.0 | 0:15.5 | 2.5 s | 390–465 |
| 5 | 0:15.5 | 0:17.5 | 2.0 s | 465–525 |
| 6 | 0:17.5 | 0:20.0 | 2.5 s | 525–600 |

---

## Setting the weather before a take

The game's weather changes on its own clock, so do not wait for it. Open the
browser console (F12) on the game page and type one line per take:

```
__wx.kind = 'rain'; __wx.level = 1; __wx.hold = 600;
```

Rain, steady, for ten minutes - Shot 1 and Shot 2.

```
__wx.kind = 'storm'; __wx.level = 1; __wx.hold = 600;
```

Storm for Shot 3. To land a lightning strike where you want it:

```
__wx.nextFlash = 0.6;
```

Set that immediately before pressing record and the strike arrives about a
second later. Back to a clear sky with `__wx.kind = 'clear';`.

Two things about this: the weather is visual only, so it cannot make a take
harder or easier, and the console line does not exist in the packaged desktop
build - if you are recording there, wait for the weather in the cycle instead,
or record the shots on the web build, which is the same game.

---

## Shot 1 — the empty street in rain · 0:00.0–0:05.0 · frames 000–150

**On screen:** daylight, the ruined outskirts from the default view, rain
falling in slanted streaks, the ground dark and wet, nothing moving. Buildings
on both sides, a burnt car, a crate leaning against a wall.

**What has to happen:** nothing. That is the shot. The only movement is the
rain and the push-in, and the push-in is done in the edit - the game camera is
fixed, so record this static and scale 100% to 106% across the five seconds,
anchored centre.

**Setup:** graphics level high (rain is thinnest at Very low - the trails almost
disappear there), daylight, wave 1 before anything has spawned nearby, pistol
equipped. Set rain from the console, then stand still and let the world sit.

**Watch for:** a zombie drifting into frame. If one does, wait for it to wander
out or start over - this shot has to read as empty or the first gunshot at 0:06
loses its job. Also check the first frame: if you set the weather and pressed
record in the same second, the rain fades in over about six seconds and the
opening frames look dry. Set the weather, wait eight seconds, then roll.

**Takes:** 2. The rain moves differently in each one; pick the take where the
streaks are densest on the right side of frame, where the eye enters.

---

## Shot 2 — first wave, still raining · 0:05.0–0:09.0 · frames 150–270

**On screen:** two or three shamblers walking in from the right side of frame
towards the survivor, who is holding the pistol and aiming right. Rain continues
from Shot 1 - same weather, no cut in the sky.

**What has to happen, in order:**

- **0:05.0 (frame 150)** — shot starts, shamblers mid-walk, at least a body-length inside frame.
- **0:06.4 (frame 192)** — first pistol shot.
- **0:06.9 (frame 207)** — second pistol shot, first shambler goes down.
- **0:07.6 (frame 228)** — reload starts (R). The reload animation is on screen here on purpose; it is the proof that ammo is a problem.
- **0:09.0 (frame 270)** — a shotgun blast lands exactly on the cut out.

**Setup:** wave 1–2, pistol, shamblers only (no runners). Stand so they approach
from screen right. Keep the remaining two shamblers alive when the shot ends -
they are the crowd the shotgun answers. Rain from the same console line as
Shot 1, so the two shots match when they cut together.

**Watch for:** a shot that misses. A miss reads as sloppy rather than tense in
four seconds, so redo the take rather than fix it in the edit. Second thing:
rain thins with distance, so do not push the zombies too far back - they need to
be inside the weather, not beyond it.

**Takes:** 3. Pick the one where the reload finishes cleanly before the blast.

---

## Shot 3 — night storm, same corner · 0:09.0–0:13.0 · frames 270–390

**On screen:** the same framing as Shot 1, now dark, in a storm: heavier and
faster rain than the day shots, wind pushing it sideways. Flashlight cone
pointing right, two runners inside the cone, one more audible and half-visible
outside it. At 0:12.4 a lightning strike lights the whole street.

**What has to happen:**

- **0:09.0 (frame 270)** — shot starts on the night street, storm running, flashlight already on.
- **0:10.2 (frame 306)** — first runner enters the cone.
- **0:11.0 (frame 330)** — flashlight off (L) for about half a second. The screen
  drops to almost nothing and the storm rain is the only thing left moving.
- **0:11.6 (frame 348)** — flashlight back on, and there is one more runner than
  before.
- **0:12.4 (frame 372)** — lightning. The street is lit for about 0.4 s and there
  are two more runners than the cone showed, closing.
- **0:13.0 (frame 390)** — cut out on the dark, the frame after the flash has
  gone.

**Setup:** wait for night in the cycle rather than forcing it; the light level in
the game is what sells the shot. Stand on the exact spot you recorded Shot 1
from - use a landmark (the crate against the wall) to line it up, because the two
shots have to feel like the same street. Set the storm from the console, then set
`__wx.nextFlash = 0.6;` and roll; if the strike lands early or late, take it
again rather than moving the flash in the edit.

**Watch for:** a brute. It will read as a different game in a four-second beat;
if one walks in, take it again. Also watch the strike against text card 3: the
card is up from 0:09.4 to 0:12.8, so the flash should be the last thing under
it, not the middle. If the strike lands at 0:11, the card is competing with it
and both lose.

**Takes:** 4. Three for the flashlight play, one more for a strike that lands in
the right quarter-second.

---

## Shot 4 — smoke, then frag · 0:13.0–0:15.5 · frames 390–465

**On screen:** a crowd of the dead in the open, smoke popping in the middle of
it, then a frag landing behind the smoke. Whichever weather is still running
carries over - if the storm is going, the wet ground throws the blast light back
at the camera, which is worth keeping in frame.

**What has to happen:**

- **0:13.0 (frame 390)** — shot starts with the crowd already thick, six or more.
- **0:13.6 (frame 408)** — smoke grenade thrown into the middle of the crowd.
- **0:14.2 (frame 426)** — frag detonates behind the smoke. This is the loudest
  moment in the trailer; it has to be a clean hit on the whole group.
- **0:15.5 (frame 465)** — cut out on the aftermath, while the corpses are still on
  screen and the HUD kill counter has just moved.

**Setup:** wave 6 or later so there are enough of them, all three weapon slots
ready, standing in the open with room to see the blast. If the storm is running,
set `__wx.nextFlash = 30;` so a stray strike cannot fire during the blast and
steal the loudest frame in the cut.

**Watch for:** the blast going off screen. If the frag lands outside frame the
shot is worthless - throw it closer than feels safe. Second thing: heavy rain
over a busy frame, so check the corpses are still legible against the ground.

**Takes:** 4. This is the shot most likely to need retakes.

---

## Shot 5 — the stamp · 0:15.5–0:17.5 · frames 465–525

**On screen:** the death stamp, held, nothing else.

**What has to happen:** die. The stamp appears and the run ends. Hold it for the
full two seconds with no camera movement, no cursor and no HUD clutter over it.

**Setup:** whatever gets you killed fastest after Shot 4 — walk into the crowd if
you have to. Record it in the same session as Shot 4 so the run is continuous.
The weather freezes when the run ends, so whatever sky you died under is the sky
in the stamp.

**Watch for:** a pause menu or any overlay. Nothing on screen but the stamp.

**Takes:** 2.

---

## Shot 6 — title · 0:17.5–0:20.0 · frames 525–600

**On screen:** black, then **ROT & RUIN**, then the small line underneath:

> Out now on Steam · fully offline · no launcher

**What has to happen:** in the editor, not the game. Title fades up over 0.4 s
starting at 0:17.6, the small line follows at 0:18.6, both hold to the end. End
on the title, not on black - some placements use the last frame before play.

---

## Capture rules for every shot

- 1920×1080, 60 fps capture, 30 fps timeline. Highest graphics level.
- HUD on. It is the proof the game is real, and Steam's own guidance says HUD
  visible gameplay is what people are looking for first.
- Hide the mouse cursor or crop 2 px off the frame.
- Record each shot as a 20–30 second clean take and cut from the middle; do not
  try to perform the trailer in one pass.
- Name the files `s1_day_street_take1.mp4`, `s2_first_wave_take1.mp4` and so on,
  so the takes stay sorted in a bin.
- Three takes minimum on every gameplay shot. The one you think is fine on the
  day is usually the one you cannot use.
- Set the weather before every take, never between pressing record and the first
  frame: it fades in over about six seconds and the seam would be visible.

## Text card timings, for the edit

| # | Line | In | Out | Frames | On screen |
| --- | --- | --- | --- | --- | --- |
| 1 | One street. No way out. | 0:00.8 | 0:04.6 | 024–138 | 3.8 s |
| 2 | Three kinds of dead. | 0:05.4 | 0:08.6 | 162–258 | 3.2 s |
| 3 | Night is a different game. | 0:09.4 | 0:12.8 | 282–384 | 3.4 s |
| 4 | How long do you last? | 0:15.7 | 0:17.3 | 471–519 | 1.6 s |

Keep all four inside the middle 80% of frame and out of the bottom 15%, where
Steam's player controls sit.
